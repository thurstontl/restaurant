<section id="footer">
      <div class="row">
        <div class="small-12 small-centered columns">
          <ul class="inline-list">
            <li><a href="https://www.facebook.com/travis.thurston">facebook</a></li>
            <li><a href="https://twitter.com/tl_thurston">twitter</a></li>
            <li><a href="https://500px.com/thurstontl">500PX</a></li>
          </ul>
        </div>
      </div>

      <div class="row">
        <div class="small-12 small-centered columns">
          <p style="color: #fff;font-size: 10px">All images provided (except for some menu items) are &copy Travis Thurston, the fat head chef. &nbsp // &nbsp Site was built with Foundation.</p>
        </div>
      </div>
    </section>
    
    
    <script src="js/jquery.js"></script>
    <script src="js/foundation.min.js"></script>
    <script>
      $(document).foundation();
    </script>

  </body>
</html>