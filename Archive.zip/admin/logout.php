<?php

include("../global.php");

$_SESSION["id"] = "";
$_SESSION["firstname"] = "";

header("Location: ../index.php");

?>