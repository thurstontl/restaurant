<?php

include("../global.php");

header("Location: login_form.php");

?>
