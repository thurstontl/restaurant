<?php $connection = mysqli_connect("localhost","root","","restaurant");
session_start();
?>